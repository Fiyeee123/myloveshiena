
// Optional interactivity or animations can be added here
console.log("Thank You Page Loaded Successfully!");
